from django.shortcuts import render

# Create your views here.


from django.shortcuts import render
from .models import Telefon

def index(request):
    telefonlar = Telefon.objects.all()
    return render(request, 'shop/index.html', {'telefonlar': telefonlar})
